import { Component, OnInit } from '@angular/core';
import { interval, Subscription } from 'rxjs';
import { QuizService } from 'src/app/services/quiz-service.service';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css'],
})
export class QuizComponent implements OnInit {
  public name: string = '';
  public questionList: any[] = [];
  public currentQuestion: number = 0;
  public points: number = 0;
  public counter: number = 20;
  public correctAnswer: number = 0;
  public inCorrectAnswer: number = 0;
  public interval$: Subscription | undefined;
  public progress: string = '0';
  public isQuizCompleted: boolean = false;

  constructor(private quizService: QuizService) { }

  ngOnInit(): void {
    this.name = localStorage.getItem('name') || '';
    this.getAllQuestions();
    this.startCounter();
  }

  getAllQuestions() {
    this.quizService.getQuestionJson().subscribe((res: { questions: any[] }) => {
      this.questionList = res.questions;
    });
  }

  nextQuestion() {
    if (!(this.questionList.length - 1 == this.currentQuestion)) {
      this.currentQuestion++;
      this.startCounter();
    }
  }

  previousQuestion() {
    if (this.currentQuestion !== 0) {
      this.currentQuestion--;
    }
  }

  answer(currentQno: number, option: any) {
    if (currentQno === this.questionList.length) {
      this.isQuizCompleted = true;
      this.stopCounter();
    }

    if (option.correct) {
      this.correctAnswer++;
      this.updateQuestionAndCounter(1000, 5);
    } else {
      this.inCorrectAnswer++;
      this.updateQuestionAndCounter(1000, -5);
    }
  }

  updateQuestionAndCounter(timeout: number, pointsChange: number) {
    setTimeout(() => {
      this.currentQuestion++;
      this.resetCounter();
      this.getProgressPercent();
      this.points += pointsChange;
    }, timeout);
  }

  startCounter() {
    this.interval$ = interval(1000).subscribe((val) => {
      this.counter--;

      if (this.counter === 0) {
        this.currentQuestion++;
        this.counter = 20;
        this.points -= 5;
        this.resetCounter();
      }
    });

    setTimeout(() => {
      this.interval$?.unsubscribe();
    }, 100000);
  }

  stopCounter() {
    this.interval$?.unsubscribe();
    this.counter = 0;
  }

  resetCounter() {
    this.stopCounter();
    this.counter = 20;
    this.startCounter();
  }

  resetQuiz() {
    this.resetCounter();
    this.getAllQuestions();
    this.points = 0;
    this.counter = 20;
    this.currentQuestion = 0;
    this.progress = '0';
  }

  getProgressPercent() {
    this.progress = ((this.currentQuestion / this.questionList.length) * 100).toString();
  }
}
